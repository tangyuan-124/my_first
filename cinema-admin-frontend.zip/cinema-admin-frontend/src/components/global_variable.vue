
<script>
const base = 'http://127.0.0.1:9231/'

export default {
  base
}

</script>
